package application;

public enum Statut {

    EN_ATTENTE,
    CONFIRME,
    ANNULE

}