package application;

public class User {
//  USING OF THIS, WE CAN DISPLAY THE USERNAME IN OUR DASHBOARD  
 public static String username;
 
}